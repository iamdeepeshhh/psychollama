package com.Chanalyst.ChanalystV1.DTO;

public record QuestionDto(Long id, String text, int round, int sequence, boolean used) {}


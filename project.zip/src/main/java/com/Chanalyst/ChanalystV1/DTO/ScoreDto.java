package com.Chanalyst.ChanalystV1.DTO;

public record ScoreDto(Long playerId, String playerName, int points) {}

